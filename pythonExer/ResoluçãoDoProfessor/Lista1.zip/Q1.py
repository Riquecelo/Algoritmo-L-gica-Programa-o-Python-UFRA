'''
Entrada: lado do quadrado

Processamentos: calcular a area

Saída: mensagem informando o valor da area

'''
lado = float(input('Informe o valor do lado do quadrado:'))
area = lado**2
print('area do quadrado = ', area)
