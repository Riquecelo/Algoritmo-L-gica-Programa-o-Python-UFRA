
temp_C = float(input('Temperatura em celcius:'))

temp_F = temp_C*1.8 + 32

print(f'{temp_C} ºC é igual a {temp_F}º F')
