frase = input('Digite uma frase:')
for i in range(10):
    print(frase)

