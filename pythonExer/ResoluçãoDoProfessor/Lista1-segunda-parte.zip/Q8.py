while True:
    print('Informe 2 numeros para o intervalo ')
    n1 = int(input('n1:'))
    n2 = int(input('n2:'))
    if n1 < 0 or n2 < 0:
        print('Erro : numeros nao podem ser negativos, tente novamente')
    else:
        break

inicio = min(n1, n2)
fim = max(n1, n2)

lista_par = list()
lista_impar = []

for i in range(inicio, fim + 1):
    if i % 2 == 0:
        lista_par.append(i)
    else:
        lista_impar.append(i)

soma_par = 0
soma_impar = 0
for i in lista_par:
    soma_par += i
for i in lista_impar:
    soma_impar += i

print(f'Lista de numeros pares = {lista_par}')
print(f'soma dos numeros da lista par = {soma_par}')
print(f'Lista de numeros impares = {lista_impar}')
print(f'soma dos numeros da lista impar = {soma_impar}')
