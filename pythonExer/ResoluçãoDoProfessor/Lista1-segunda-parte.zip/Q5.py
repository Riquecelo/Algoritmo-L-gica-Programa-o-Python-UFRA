'''
1 - pedir os 2 numeros
2 - testar os numeros para ver se sao validos ( positivo)
    - caso seja invalido , pedir 2 numeros novamente
3 - caso seja valido fazer o seguinte
4 - calcular o somarotiro dos numeros inteiros entre esse dois numeros
'''

while True:
    print('Informe 2 numeros para o intervalo ')
    n1 = int(input('n1:'))
    n2 = int(input('n2:'))
    if n1 < 0 or n2 < 0:
        print('Erro : numeros nao podem ser negativos, tente novamente')
    else:
        break

inicio = min(n1, n2)
fim = max(n1, n2)
soma = 0
for i in range(inicio, fim + 1):
    soma = soma + i

print(f'soma dos numeros inteiros entre {inicio} e {fim} = {soma}')
