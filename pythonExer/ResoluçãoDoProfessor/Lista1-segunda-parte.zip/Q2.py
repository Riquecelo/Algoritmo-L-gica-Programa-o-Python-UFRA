print('Informe 2 numeros para o intervalo ')
n1 = int(input('n1:'))
n2 = int(input('n2:'))

inicio = min(n1, n2)
fim = max(n1, n2)

print(f'numeros pares entre {inicio} e {fim}')
for i in range(inicio, fim + 1):
    if i % 2 != 0:
        print(i, end='  ')
print()
