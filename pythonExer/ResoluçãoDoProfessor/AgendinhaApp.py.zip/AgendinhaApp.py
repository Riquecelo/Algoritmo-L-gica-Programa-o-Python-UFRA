
from beautifultable import BeautifulTable
agenda = list()
tab = BeautifulTable()

while True:

    print('''
            Agendinha - escolha sua opção
            0 - sair
            1 - novo contato
            2 - listar contatos
            3 - editar contatos
            4 - apagar contato
    ''')

    op = int(input('>:'))

    if op == 0:
        print('Obrigado por usar a agendinha - bye!!!')
        break
    elif op == 1:
        print('Adicionando novo contato')
        nome = input('Informe o nome:')  
        tel = input('Informe o telefone:')
        mail = input('email:')
        niver = input('Data de aniversario:')
        contato = {'nome': nome, 'telefone': tel, 'mail': mail,'aniversario': niver }
        agenda.append(contato)
    
    elif op == 2:
        print('Contatos cadastrados')
        tab.columns.header = ["Nome", "Telefone", "Email", 'Aniversario']
        for c in agenda:
            tab.rows.append([c['nome'],c['telefone'], c['mail'],c['aniversario'] ])
        print(tab)
        tab.clear()
        
    elif op == 3:
        pass        
    elif op == 5:
        print(agenda)
    else:
        print('Erro comando não programado')


       